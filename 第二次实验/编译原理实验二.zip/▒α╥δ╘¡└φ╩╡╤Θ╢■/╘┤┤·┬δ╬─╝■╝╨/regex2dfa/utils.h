#ifndef UTILS_H
#define UTILS_H

int getPriority(const char &op);
bool isOperator(const char &ch);

#endif // UTILS_H
